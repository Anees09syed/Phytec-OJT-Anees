#ifndef INC_TIM_H_
#define INC_TIM_H_
#define SR_UIF (1U<<0)
#include "stm32f4xx.h"
void tim2_1hz_init(void);
void tim_delay(void);
#endif
